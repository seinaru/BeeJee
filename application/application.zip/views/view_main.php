<?php
    Model_Main::admin();
    Model_Main::dataCheck();
    $params = Model_Main::getParams();
?>
<script src="/js/preview.js"></script>
<?php //if ($_SESSION['auth']==true) $display = 'none'; else $display = ''; ?>
<form action="/" method="post">
    <input type="hidden" name="form" value="auth">
    <input type="text" name="login" placeholder="login" value="" style="float: left; margin-right: 10%">
    <input type="password" placeholder="password" name="password" value="">
    <p><input type="submit"  value="войти"></p>
</form>
<?php
/******* проверка введеных данных *******/
?>
    <h2>Добавить новую задачу:</h2>
    <form action="/" method="post" id="commentform" enctype="multipart/form-data" name="post">
        <input type="hidden" name="form" value="newPost">

        <p>
            <input type="text" name="author" id="author" value="" size="22" tabindex="1">
            <label for="author">Имя</label>
        </p>

        <p>
            <input type="text" name="email" id="email" value="" size="22" tabindex="2">
            <label for="email">Email</label>
        </p>

        <p>
            <textarea name="comment" id="comment" cols="60%" rows="10" tabindex="4" placeholder="Введите задачу"></textarea>
        </p>
        <div id="comment-preview-block" style="display: none">
            <h2>Предпросмотр комментария:</h2>
            <div id="comment-preview">
                <div>
                    <strong id="preview-url"></strong>&nbsp;пишет:</div><div id="ctext">

                </div>
            </div>
        </div>
        <input type="hidden" name="MAX_FILE_SIZE" value="10000000">
        <p>Прикрепить файл: <input name="userfile" type="file" multiple accept="image/png,image/jpg,image/jpeg"></p>

        <p><input type="button" value="Проверить" onclick="Show()"></p>
        <p>
            <input name="submit" type="submit" id="submit" value="Отправить задачу" tabindex="5">
        </p>
    </form>
<?php

    /***** вывод сортировки *****/
?>
<script type="text/javascript">
    function Sorter()
    {
        document.getElementById('go').submit();
    }
</script>

<form action="/" method="get" name="go" >
    <p><select size="1"  name="hero[]" onchange="this.form.submit()">
            <option selected disabled>Выберите тип сортировки</option>
            <option value="id_A">Снять сортировку</option>
            <option value="name_A">User from A to Z</option>
            <option value="name_Z">User from Z to A</option>
            <option value="email_A">Email from A to Z</option>
            <option value="email_Z">Email from Z to A</option>
            <option value="progress_A">Показать сначала выполненые задачи</option>
            <option value="progress_Z">Показать сначала не выполненые задачи</option>
        </select></p>
</form>
<?php
    /****** вывод постов *****/
foreach ($params['posts'] as $value)
{
?><div>
    <div style="display: inline-block; width: 100%; text-indent: 0.8em;">
        <p style="float: left; width: 30%;">
            User: <b><?php print_r($value['name']); ?></b>
        </p>
        <p>
            Email: <b><?php print_r($value['email']);?></b>
        </p>
        <p style="float: left; margin-right: 10px">Post №<?php print_r($value['id']);?></p>
        <?php if ($value['progress']=='done') echo'<img src="../../images/done.png" width="80px">'; ?>
    </div>
    <div style="display: inline-block;">
        <div style="display: block;">
            <p>
                <?php if ($value['image']!== '') echo '<img src="../../images/'.$value['image'].'" style="float: left;" />'; ?>
                <span style="padding: 10px; text-indent: 1.5em;"><?php print_r($value['message']);?></span>

            </p>
        </div>
    </div>
</div>
    <hr style="margin-top: 10px;">
<?php
}
/****** навигация по страницам ******/
    Model_Main::pageNav($params['pageSort'], $params['pageNum']);
?>

<script type="text/javascript">
    function Sorter()
    {
        document.getElementById('go').submit();
    }
</script>

<form action="/" method="get" name="go" >
    <p><select size="1"  name="hero[]" onchange="this.form.submit()">
            <option selected disabled>Выберите тип сортировки</option>
            <option value="id_A">Снять сортировку</option>
            <option value="name_A">User from A to Z</option>
            <option value="name_Z">User from Z to A</option>
            <option value="email_A">Email from A to Z</option>
            <option value="email_Z">Email from Z to A</option>
            <option value="progress_A">Показать сначала выполненые задачи</option>
            <option value="progress_Z">Показать сначала не выполненые задачи</option>
        </select></p>
</form>
