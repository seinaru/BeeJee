<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
	<title>Главная</title>
    <link rel="stylesheet" type="text/css" href="/css/style.css" />
	<script type="text/javascript" src="/js/preview.js"></script>
    <script src="/js/jquery-1.6.2.js" type="text/javascript"></script>
	<script type="text/javascript" src="http://www.google.com/jsapi"></script>
	<script type="text/javascript">google.load("jquery", "1.2.6");</script>
</head>
<body>
	<?php include 'application/views/'.$content_view;?>
</body>
</html>